// function checkPass() {
//   const pass1 = document.getElementById('pass1');
//   const pass2 = document.getElementById('pass2');
//   const message = document.getElementById('confirmMessage');
//   const goodColor = '#66cc66';
//   const badColor = '#ff6666';

//   if (pass1.value === pass2.value) {
//     pass2.style.backgroundColor = goodColor;
//     message.style.color = goodColor;
//     message.innerHTML = 'Passwords match!';
//     document.getElementById('submit').disabled = false;
//   } else if ((pass2.value.length > pass1.value.length)) {
//     pass2.style.backgroundColor = badColor;
//     message.style.color = badColor;
//     message.innerHTML = 'Passwords do not match!';
//     document.getElementById('submit').disabled = true;
//   } else if ((pass2.value.length < pass1.value.length)) {
//     pass2.style.backgroundColor = badColor;
//     message.style.color = badColor;
//     // message.innerHTML = 'Passwords do not match!';
//     document.getElementById('submit').disabled = true;
//   }
// }


function checkPass() {
  const password = document.getElementById('password');
  const confirm_password = document.getElementById('confirm_password');

  if (password.value != confirm_password.value) {
    confirm_password.setCustomValidity('Passwords MisMatch');
  } else {
    confirm_password.setCustomValidity('');
  }
} 

history.pushState(null, null, document.URL);
window.addEventListener('popstate', function () {
    history.pushState(null, null, document.URL);
});