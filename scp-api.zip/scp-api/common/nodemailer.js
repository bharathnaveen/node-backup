const nodemailer = require('nodemailer');

const sendMailConfig = (name, email, encryptedEmailString) => {
  // create reusable transporter object using the default SMTP transport
  const transporter = nodemailer.createTransport({
    service: process.env.EMAIL_SERVICE, // move all to .env file
    host: process.env.EMAIL_HOST,
    secureConnection: false,
    port: process.env.EMAIL_PORT, // true for 465, false for other ports
    auth: {
      user: process.env.EMAIL_AUTH_USER,
      pass: process.env.EMAIL_AUTH_PASSWORD,
    },
  });
 
  const emailBody = `
  <h4>Hi ${name},</h4>
  <b>Thank you for registering your Sennnovate Customer Portal account. To instantly activate your account please click the following link.</b> 
  </br>
  <p><a href=${process.env.MAIL_URL}/${encryptedEmailString}>Click this link to activate your account</a></p>
  </br>
  <p><b>Thanks,</b></p
  <p>Your Sennnovate Customer Portal Team</p>
  </br>
  <p>Sennovate Inc.</p>
  <p>Sennovate Inc, Suite 110, 2430 Camino Ramon, San Ramon, CA 94583</p>
  <p>Phone: +1 (925) 322 4379  | INDIA: +91 98948 39869 | Fax: +1 (630) 206 1451</p>
  <p>Email : sales@sennovate.com</p>
  <p>Web : www.sennovate.com</p>
  <p>Identity & Access | Managed Services</p>              
  `;

  const mailOptions = {
    from: '"SCP" <bmohan@sennovate.com>', // sender address
    to: email, // list of receivers
    subject: 'Sennovate Customer Portal', // subject line
    html: emailBody, // email body
  };

  return transporter.sendMail(mailOptions, (errInMailer, info) => {
    if (errInMailer) {
      return res.status(500).json({ message: 'Mail delivery failed', success: false });
    }
    return res.status(200).json({ info });
  });
};

module.exports = {
  sendMailConfig,
};
