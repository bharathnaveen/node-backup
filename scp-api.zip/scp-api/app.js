require('dotenv').config();

const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const cors = require('cors');
const helmet = require('helmet');
const RateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const CryptoJS = require('crypto-js');

const User = require('./models/user');

mongoose.Promise = global.Promise;
const mongoURI = 'mongodb://127.0.0.1/SCP';
// const mongoURI = `mongodb://${process.env.MONGO_USER}:${process.env.MONGO_PASS}@${process.env.MONGO_HOST}:${process.env.MONGO_PORT}/${process.env.MONGO_DBNAME}`;
// const mongoOptions = { useMongoClient: true };
mongoose.connect(mongoURI);
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => console.log('MONGO DB Connected..!!'));

let userPassword = CryptoJS.AES.encrypt('admin123', process.env.APP_SECRET);
userPassword = userPassword.toString();

User.findOne({
  email: 'product@sennovate.com',
}, (err, users) => { // adding super admin in intial while system start
  if (!err && users === null) {
    const superAdmin = new User();
    superAdmin.email = 'product@sennovate.com';
    superAdmin.name = 'Product Admin';
    superAdmin.password = userPassword;
    superAdmin.role = 'PA';
    superAdmin.activated = true;
    superAdmin.save();
  }
});

const limiter = new RateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  delayMs: 0, // disable delaying - full speed until the max limit is reached
});

const indexRouter = require('./routes/index');
const clients = require('./routes/clients');
const users = require('./routes/users');
const auth = require('./routes/auth');
const activation = require('./routes/activation');
const tickets = require('./routes/tickets');
const projects = require('./routes/projects');
const roles = require('./routes/role');
const feedbacks = require('./routes/feedbacks');

const app = express();

app.use(cors());
// app.use(compression());
app.use(helmet());
// app.enable('trust proxy'); // only if you're behind a reverse proxy (Heroku, Bluemix, AWS if you use an ELB, custom Nginx setup, etc)
app.use(limiter);

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/login', (req, res) => {
  User.find({ email: req.body.userName }, (err, user) => {
    if (err) {
      return res.status(500).json({ message: 'Login failed', success: false });
    }
    if (user.length > 0) {
      let password = CryptoJS.AES.decrypt(user[0].password, process.env.APP_SECRET);
      password = password.toString(CryptoJS.enc.Utf8);
      const userString = JSON.stringify(user);
      if (password === req.body.pass) {
        const token = jwt.sign({ user: userString }, process.env.APP_SECRET, { expiresIn: process.env.TOKEN_EXPIRY });
        res.status(200).json({
          users: user[0], token, success: true, message: 'Successfully Login',
        });
      } else {
        return res.status(200).json({ message: 'Invalid Credentials', success: false });
      }
    } else {
      return res.status(200).json({ message: 'User not found', success: false });
    }
  });
});

app.use('/getuser', (req, res) => {
  const token = req.body.getToken;
  jwt.verify(token, process.env.APP_SECRET, (err, decoded) => {
    if (err) return res.status(500).send({ auth: false, message: 'Failed to authenticate token.' });
    const loginObj = JSON.parse(decoded.user);
    return res.status(200).json({ users: loginObj[0] });
  });
});

app.use('/activation', activation);
app.use('/users', users);
app.use('/tickets', tickets);
app.use('/feedbacks', feedbacks);

app.use((req, res, next) => {
  const bearerHeader = req.headers.authorization;
  if (typeof bearerHeader !== 'undefined') {
    const bearerToken = bearerHeader.split(' ')[1];
    req.authToken = bearerToken;
    return next();
  }
  return res.sendStatus(401);
});

app.use((req, res, next) => {
  jwt.verify(req.authToken, process.env.APP_SECRET, (err) => {
    if (err) return res.sendStatus(401);
    return next();
  });
});


app.use('/', indexRouter);
app.use('/auth', auth);
app.use('/clients', clients);
app.use('/projects', projects);
app.use('/roles', roles);


// catch 404 and forward to error handler
app.use((req, res, next) => {
  next(createError(404));
});

// error handler
app.use((err, req, res) => {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
