const mongoose = require('mongoose');

const { Schema } = mongoose;
const RoleSchema = new mongoose.Schema(
  {
    email: {
      type: String, required: true, trim: true, lowercase: true, unique: true, match: /\S+@\S+\.\S+/, // Match validation via regex
    },
    role: { type: String },
  },
  {
    timestamps: { createdAt: 'createdAt' },
  },
);

module.exports = mongoose.model('Role', RoleSchema);
