const mongoose = require('mongoose');

const { Schema } = mongoose;
const TicketSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String, required: true },
    priority: { type: String, required: true },
    severity: { type: String, required: true },
    attachment: { type: String },
    project: { type: Schema.Types.ObjectId, ref: 'Project' },
    client: { type: Schema.Types.ObjectId, ref: 'Client' },
    user: { type: Schema.Types.ObjectId, ref: 'User' },
    status: { type: String, required: true },
    converstaion: [{ type: Schema.Types.Mixed }],
    resolvedAt: { type: Date },
    raisedBy: { type: String, required: true },
    application: { type: String },
  },
  {
    timestamps: { createdAt: 'createdAt' },
  },
);

module.exports = mongoose.model('Ticket', TicketSchema);
