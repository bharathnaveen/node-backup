const mongoose = require('mongoose');

const { Schema } = mongoose;
const UserSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: {
      type: String, required: true, trim: true, lowercase: true, unique: true, match: /\S+@\S+\.\S+/, // Match validation via regex
    },
    mobile: { type: Number },
    client: { type: Schema.Types.ObjectId, ref: 'Client' },
    projects: [{ type: Schema.Types.ObjectId, ref: 'Project' }],
    password: { type: String },
    role: { type: String, required: true },
    activated: { type: Boolean, required: true },
    tickets: [{ type: Schema.Types.ObjectId, ref: 'Ticket' }],
  },
  {
    timestamps: { createdAt: 'createdAt' },
  },
);

module.exports = mongoose.model('User', UserSchema);
