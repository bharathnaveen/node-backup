const mongoose = require('mongoose');

const { Schema } = mongoose;
const FeedbackSchema = new mongoose.Schema(
    {
        input: { text: String },
        output: {
            text: [ String ]
        },
        context: {
            conversation_id: String,
            response: [{
                 responseType: String, 
                    options: [{
                        id: String,
                        more: String, 
                        name: String, 
                        description: String, 
                        returnValue: String
                    }]
                }],
        },
        user: {
            name: String,
            email: String,
            comment: String
        }
    }
);

module.exports = mongoose.model('Feedback', FeedbackSchema);