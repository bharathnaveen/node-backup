const mongoose = require('mongoose');

const { Schema } = mongoose;
const ClientSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, unique: true, trim: true },
    website: { type: String },
    mailDomains: [{ type: String }],
    users: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    projects: [{ type: Schema.Types.ObjectId, ref: 'Project' }],
  },
  {
    timestamps: { createdAt: 'createdAt' },
  },
);

module.exports = mongoose.model('Client', ClientSchema);