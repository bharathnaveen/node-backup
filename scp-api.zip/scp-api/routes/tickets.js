const express = require('express');

const router = express.Router();
const Ticket = require('../models/ticket');
const User = require('../models/user');

router
  .post('/ticketlist', (req, res) => {
    User.find({ _id: req.body.userId }).populate('tickets').select('name tickets').exec((error, tickets) => {
      if (error) res.status(500).json({ message: 'DB error', success: false });
      res.status(200).json({ tickets: tickets[0].tickets });
    });
  })


  .post('/', (req, res) => {
    const {
      project, client, title, description, priority,
      severity, attachment, raisedBy, application, user,
    } = req.body;
    const ticket = new Ticket({
      project, client, title, description, priority,
       severity, attachment, status: 'New', raisedBy,
        application, user,
    });
    ticket.save((err, tickets) => {
      User.findOneAndUpdate({ _id: tickets.user }, { $push: { tickets: tickets._id } }, () => { });
      // User.findByIdAndUpdate(raisedBy, { $push: { tickets: tickets._id } }, () => { });
      if (err) return res.status(500).json({ message: 'Insertion failed', success: false, err });
      res.status(200).json({ message: `Ticket - ${tickets.title} created`, success: true });
    });
  })

  .post('/update', (req, res) => {
    const { ticket } = req.body;
    Ticket.findByIdAndUpdate({ _id: ticket['_id'] }, { ...ticket }, (err, update) => {
      if (err) return res.status(500).json({ message: 'Insertion failed', success: false });
      return res.status(200).json({ message: `Ticket - ${update.title} updated`, success: true });
    });
  });

module.exports = router;
