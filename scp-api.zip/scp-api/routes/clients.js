const express = require('express');

const router = express.Router();
const Client = require('../models/client');


router
  .post('/delete', (req, res) => {
    Client.remove({ _id: req.body.clientId }, (error) => {
      if (error) return res.status(500).json({ message: 'DB error', success: false });
      return res.status(200).json({ message: 'Deleted successfully', success: true });
    });
  })

  .get('/clientlist', (req, res) => {
    Client.find({}, (error, clients) => {
      if (error) res.status(500).json({ message: 'DB error', success: false });
      res.status(200).json({ clients });
    });
  })

  .post('/', (req, res) => {
    const { name, website, mailDomains } = req.body;
    const client = new Client({
      name, website, mailDomains,
    });
    client.save((err, clients) => {
      if (err) return res.status(500).json({ message: 'Insertion failed', success: false });
      res.status(200).json({ message: `Client - ${clients.name} created`, success: true });
    });
  })

  .post('/update', (req, res) => {
    const { name, website, mailDomains, _id } = req.body;
    Client.findOneAndUpdate({ _id }, { name, website, mailDomains }, (err, update) => {
      if (err) return res.status(500).json({ message: 'Insertion failed', success: false });
      return res.status(200).json({ message: `Client - ${update.name} updated`, success: true });
    });
  });

module.exports = router;
