const express = require('express');

const router = express.Router();
const Project = require('../models/project');
const Client = require('../models/client');


router
  .post('/delete', (req, res) => {
    Client.findOneAndUpdate({ _id: req.body.client }, { $pull: { projects: req.body.projectId } }, () => { });
    Project.remove({ _id: req.body.projectId }, (error) => {
      if (error) return res.status(500).json({ message: 'DB error', success: false });
      return res.status(200).json({ message: 'Deleted successfully', success: true });
    });
  })

  .get('/projectlist', (req, res) => {
    Project.find({}).populate('client').exec((error, projects) => {
      if (error) res.status(500).json({ message: 'DB error', success: false });
      res.status(200).json({ projects });
    });
  })

  .post('/', (req, res) => {
    const { name, tickets, client } = req.body;
    const project = new Project({
      name, tickets, client,
    });
    project.save((err, projects) => {
      Client.findOneAndUpdate({ _id: projects.client }, { $push: { projects: projects._id } }, () => { });
      if (err) return res.status(500).json({ message: 'Insertion failed', success: false });
      res.status(200).json({ message: `Project - ${projects.name} created`, success: true });
    });
  })

  .post('/update', (req, res) => {
    const { name, _id } = req.body;
    Project.findOneAndUpdate({ _id }, { name }, (err, update) => {
      if (err) return res.status(500).json({ message: 'Insertion failed', success: false });
      return res.status(200).json({ message: `Project - ${update.name} updated`, success: true });
    });
  });

module.exports = router;
