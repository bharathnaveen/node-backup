const express = require('express');
const CryptoJS = require('crypto-js');
const User = require('../models/user');

const router = express.Router();

router.get('/:ciphertext', (req, res) => {
  let { ciphertext } = req.params;
  /**
   * Since the Encryto js results '/' forward slashes in encrypted text,
   * it will fail in browser url (PUG based view).
   * To fix '/' issue in Crypto-js, use encode/decodeURIComponent when passing.
   * encrypted key in as an query param in url.
   */
  ciphertext = decodeURIComponent(ciphertext);
  const bytes = CryptoJS.AES.decrypt(ciphertext.toString(), process.env.APP_SECRET);
  const decryptedText = bytes.toString(CryptoJS.enc.Utf8);

  const userObj = JSON.parse(decryptedText);

  User
    .find({ email: userObj.userEmail }, (error, user) => {
      if (error) return res.send(400).json({ message: 'Error occured! try again', success: false });
      const { name, email, activated } = user[0];
      if (activated) {
        console.log(typeof activated, 'Active34534543');
        return res.render('activation-success', { email: user.email, name: user.name, redirectionURL: process.env.URL });
      }
      return res.render('activation', { name, email });
    });
});

router.post('/', (req, res) => {
  const { password: userpass1, email } = req.body;
  let password = CryptoJS.AES.encrypt(userpass1, process.env.APP_SECRET);
  password = password.toString();

  User
    .findOneAndUpdate(
      { email },
      { activated: true, password }, { upsert: true }, (error, user) => {
        if (error) return res.status(500).json({ message: 'DB error', success: false });
        res.render('activation-success', { email: user.email, name: user.name, redirectionURL: process.env.URL });
      },
  );
});

module.exports = router;

