
const express = require('express');

const router = express.Router();
const Feedback = require('../models/feedback');

router
    .post('/', (req, res) => {
        const { 
            input, output, context, user
        } = req.body;
        const feedback = new Feedback ({
            input, output, context, user
        });
        feedback.save((err, feedback) => {
            if (err) return res.status(500).json({ message: 'Insertion failed', success: false });
            return res.status(200).json({ message: `Ticket created successfully`, success: true });
        });
    });

module.exports = router;