const express = require('express');
const CryptoJS = require('crypto-js'); // for secret key encryption

const router = express.Router();
const User = require('../models/user');
const Client = require('../models/client');
const { sendMailConfig } = require('../common/nodemailer');

router
  // .post('/delete', (req, res) => {
  //   User.remove({ _id: req.body.userId }, (error) => {
  //     if (error) return res.status(500).json({ message: 'DB error', success: false });
  //     return res.status(200).json({ message: 'Deleted successfully', success: true });
  //   });
  // })

  .get('/userlist', (req, res) => {
    User.find({}).populate('client').exec((error, users) => {
      if (error) res.status(500).json({ message: 'DB error', success: false });
      res.status(200).json({ users });
    });
  })


  .post('/', (req, res) => {
    const { name, mobile } = req.body;
    const email = req.body.email ? req.body.email.toLowerCase().trim() : '';
    const emailRegex = /^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/; // regex email pattern

    if (emailRegex.test(email)) {
      User.findOne({ email }, (error, userInfo) => {
        if (error) return res.status(500).json({ message: 'DB error', success: false });
        if (userInfo && userInfo.email) return res.status(409).json({ message: `Client - ${email} already registered`, success: false });

        const user = new User({
          name, mobile, email, activated: false, role: 'User',
        });
        const domain = email.substring(email.lastIndexOf('@') + 1);

        Client.find({ mailDomains: { $all: [domain] } }, (err, client) => {
          if (client.length == 0) {
            user.save((errorOnSave, userInstance) => {
              if (errorOnSave) return res.status(500).json({ message: 'Insertion failed', success: false });
              res.status(200).json({ message: `User - ${userInstance.email} created`, success: true });

              const userEmail = userInstance.email;
              const userName = userInstance.name;
              const stringObj = { userEmail, userName };
              const stringToEncode = JSON.stringify(stringObj);
              const encryptedEmailString =
                encodeURIComponent(CryptoJS.AES.encrypt(stringToEncode, process.env.APP_SECRET));

              sendMailConfig(userName, userEmail, encryptedEmailString);
            });
          } else {
            user.client = client[0]._id;
            user.save((errorOnSave, userInstance) => {
              Client.findOneAndUpdate({ _id: userInstance.client }, { $push: { users: userInstance._id } }, () => { });
              if (errorOnSave) return res.status(500).json({ message: 'Insertion failed', success: false });
              res.status(200).json({ message: `User - ${userInstance.email} created`, success: true });

              const userEmail = userInstance.email;
              const userName = userInstance.name;
              const stringObj = { userEmail, userName };
              const stringToEncode = JSON.stringify(stringObj);
              const encryptedEmailString =
                encodeURIComponent(CryptoJS.AES.encrypt(stringToEncode, process.env.APP_SECRET));

              sendMailConfig(userName, userEmail, encryptedEmailString);
            });
          }
        });
      });
    }
  })

  .post('/update', (req, res) => {
    const { name, mobile, role, _id, client } = req.body;
    User.findOneAndUpdate({ _id }, { name, mobile, role, client }, (err, update) => {
      if (err) return res.status(500).json({ message: 'Insertion failed', success: false });
      return res.status(200).json({ message: `User - ${update.name} updated`, success: true });
    });
  });

module.exports = router;
