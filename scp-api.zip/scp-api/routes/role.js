const express = require('express');

const router = express.Router();
const Role = require('../models/role');
const User = require('../models/user');


router
  .post('/delete', (req, res) => {
    Role.remove({ _id: req.body.roleId }, (error) => {
      if (error) return res.status(500).json({ message: 'DB error', success: false });
      return res.status(200).json({ message: 'Deleted successfully', success: true });
    });
  })


  .get('/userlist', (req, res) => {
    User.find({}, (error, users) => {
      if (error) res.status(500).json({ message: 'DB error', success: false });
      res.status(200).json({ users });
    });
  })

  .get('/rolelist', (req, res) => {
    Role.find({}, (error, roles) => {
      if (error) res.status(500).json({ message: 'DB error', success: false });
      res.status(200).json({ roles });
    });
  })

  .post('/', (req, res) => {
    const { email, role } = req.body;
    const roles = new Role({
      email, role,
    });
    roles.save((err, roleInfo) => {
      User.findOneAndUpdate({ email: roleInfo.email }, { role }, () => { });
      if (err) return res.status(500).json({ message: 'Insertion failed', success: false });
      res.status(200).json({ message: `Role - ${roleInfo.email} created`, success: true });
    });
  });

module.exports = router;
